require 'socket' # Sockets are in standard library

hostname = '127.0.0.1'
port = 10000

puts "\t=== PASSO 01 ==="
puts "[CA:C] Passo 01: Tentando conexao com a camada inferior"
s = TCPSocket.open(hostname, port)
puts "[CA:C] Passo 01: Conexao bem sucedida. Aguardar dados.\n"

response = ""

while response == ""
	# Le as linhas do socket
	while line = s.gets
		# alem de armazenar na variavel local
		response += line.chop
	end
end

puts "\n\t=== PASSO 15 ==="
puts "[CA:C] Passo 15: Dados recebidos. Iniciando servidor web."

# Criando PDU em arquivo
arq = open("./src/network/pdu/P14-CT-segmento.txt", "w")
arq.write(response)
arq.close()

# Encerra conexao
s.close

# Criando PDU em arquivo
arq = open("./src/network/pdu/P15-CA-dados.txt", "w")
arq.write(response)
arq.close()

# Inicia o servidor web, de forma que ficara disponivel o conteudo recebido no IP:porta no navegador
hostfile = File.open("./src/network/hostfile/hostfile-client.txt", "rb")
hostname = hostfile.read

webserver = TCPServer.new(hostname, 8080)
while (session = webserver.accept)
	session.print "HTTP/1.1 200/OK\r\nContent-type:text/html\r\n\r\n"
	session.print response
	session.close
end
