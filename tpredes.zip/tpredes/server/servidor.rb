require 'socket'               # Get sockets from stdlib

filename = "./src/index.html"
begin
	displayfile = File.open(filename, 'r')
	content = displayfile.read()
end

# Socket fica escutando a porta 10006
server = TCPServer.open(10006)

loop {
	# Servidores ficam executando para sempre
	# Espera camada inferior conectar
	client = server.accept
	puts "\n\t=== PASSO 07 ==="
	puts "[CA:S] Passo 07: Conexao chegou."

	puts "\n\t=== PASSO 08 ==="
	puts "[CA:S] Passo 08: Enviando conteudo."

	# Criando PDU em arquivo
	arq = open("./src/network/pdu/mensagem.txt", "w")
	arq.write(content)
	arq.close()

	# Envia o arquivo solicitado para camada inferior
	client.puts(content)

	# Encerra conexao com camada inferior
	client.close
}
